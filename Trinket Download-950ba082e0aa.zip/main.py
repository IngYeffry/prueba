
def convertir_longitud(valor, unidad_origen, unidad_destino):
    factores = {
        "m": 1, "cm": 0.01, "mm": 0.001, "km": 1000,
        "inch": 0.0254, "ft": 0.3048, "yd": 0.9144, "mile": 1609.34
    }
    return valor * factores[unidad_origen] / factores[unidad_destino]

def convertir_masa(valor, unidad_origen, unidad_destino):
    factores = {
        "kg": 1, "g": 0.001, "mg": 0.000001, "lb": 0.453592, "oz": 0.0283495
    }
    return valor * factores[unidad_origen] / factores[unidad_destino]

def convertir_temperatura(valor, unidad_origen, unidad_destino):
    if unidad_origen == "C" and unidad_destino == "F":
        return valor * 9/5 + 32
    elif unidad_origen == "F" and unidad_destino == "C":
        return (valor - 32) * 5/9
    elif unidad_origen == "C" and unidad_destino == "K":
        return valor + 273.15
    elif unidad_origen == "K" and unidad_destino == "C":
        return valor - 273.15
    elif unidad_origen == "F" and unidad_destino == "K":
        return (valor - 32) * 5/9 + 273.15
    elif unidad_origen == "K" and unidad_destino == "F":
        return (valor - 273.15) * 9/5 + 32
    else:
        return valor

def convertir_volumen(valor, unidad_origen, unidad_destino):
    factores = {
        "L": 1, "mL": 0.001, "cm3": 0.001, "m3": 1000, "gal": 3.78541
    }
    return valor * factores[unidad_origen] / factores[unidad_destino]

def main():
    print("Seleccione el tipo de conversión:")
    print("1. Longitud")
    print("2. Masa")
    print("3. Temperatura")
    print("4. Volumen")
    
    opcion = input("Ingrese el número de la opción: ")
    valor = float(input("Ingrese el valor a convertir: "))
    unidad_origen = input("Ingrese la unidad de origen: ")
    unidad_destino = input("Ingrese la unidad de destino: ")
    
    if opcion == "1":
        resultado = convertir_longitud(valor, unidad_origen, unidad_destino)
    elif opcion == "2":
        resultado = convertir_masa(valor, unidad_origen, unidad_destino)
    elif opcion == "3":
        resultado = convertir_temperatura(valor, unidad_origen, unidad_destino)
    elif opcion == "4":
        resultado = convertir_volumen(valor, unidad_origen, unidad_destino)
    else:
        print("Opción no válida")
        return
    
    print("El resultado es: {resultado} {unidad_destino}")

def convertir_longitud(valor, unidad_origen, unidad_destino):
    factores = {
        "m": 1, "cm": 0.01, "mm": 0.001, "km": 1000,
        "inch": 0.0254, "ft": 0.3048, "yd": 0.9144, "mile": 1609.34
    }
    return valor * factores[unidad_origen] / factores[unidad_destino]

def convertir_masa(valor, unidad_origen, unidad_destino):
    factores = {
        "kg": 1, "g": 0.001, "mg": 0.000001, "lb": 0.453592, "oz": 0.0283495
    }
    return valor * factores[unidad_origen] / factores[unidad_destino]

def convertir_temperatura(valor, unidad_origen, unidad_destino):
    if unidad_origen == "C" and unidad_destino == "F":
        return valor * 9/5 + 32
    elif unidad_origen == "F" and unidad_destino == "C":
        return (valor - 32) * 5/9
    elif unidad_origen == "C" and unidad_destino == "K":
        return valor + 273.15
    elif unidad_origen == "K" and unidad_destino == "C":
        return valor - 273.15
    elif unidad_origen == "F" and unidad_destino == "K":
        return (valor - 32) * 5/9 + 273.15
    elif unidad_origen == "K" and unidad_destino == "F":
        return (valor - 273.15) * 9/5 + 32
    else:
        return valor

def convertir_volumen(valor, unidad_origen, unidad_destino):
    factores = {
        "L": 1, "mL": 0.001, "cm3": 0.001, "m3": 1000, "gal": 3.78541
    }
    return valor * factores[unidad_origen] / factores[unidad_destino]

def main():
    print("Seleccione el tipo de conversión:")
    print("1. Longitud")
    print("2. Masa")
    print("3. Temperatura")
    print("4. Volumen")
    
    opcion = input("Ingrese el número de la opción: ")
    valor = float(input("Ingrese el valor a convertir: "))
    unidad_origen = input("Ingrese la unidad de origen: ")
    unidad_destino = input("Ingrese la unidad de destino: ")
    
    if opcion == "1":
        resultado = convertir_longitud(valor, unidad_origen, unidad_destino)
    elif opcion == "2":
        resultado = convertir_masa(valor, unidad_origen, unidad_destino)
    elif opcion == "3":
        resultado = convertir_temperatura(valor, unidad_origen, unidad_destino)
    elif opcion == "4":
        resultado = convertir_volumen(valor, unidad_origen, unidad_destino)
    else:
        print("Opción no válida")
        return
    
    print("El resultado es: {resultado} {unidad_destino}")

if __name__ == "__main__":
    main()

